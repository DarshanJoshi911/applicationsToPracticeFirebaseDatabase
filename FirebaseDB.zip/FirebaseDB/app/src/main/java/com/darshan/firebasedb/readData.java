package com.darshan.firebasedb;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import org.w3c.dom.Text;

public class readData extends AppCompatActivity {
EditText read;
Button get,back,del;
TextView data,data1,data2,data3;
DatabaseReference ref,ref2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_read_data);

        read = (EditText)findViewById(R.id.find);
        get = (Button)findViewById(R.id.button3);
        back = (Button)findViewById(R.id.button4);
        del = (Button)findViewById(R.id.button5);
        data = (TextView)findViewById(R.id.txt);
        data1 = (TextView)findViewById(R.id.txt1);
        data2 = (TextView)findViewById(R.id.txt2);
        data3 = (TextView)findViewById(R.id.txt3);

        del.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
        ref2  = FirebaseDatabase.getInstance().getReference().child("user").child(read.getText().toString().trim());
        ref2.removeValue();


            }
        });

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(v.getContext(), MainActivity.class);
                startActivity(intent);
            }
        });

        get.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

    ref  = FirebaseDatabase.getInstance().getReference().child("user").child(read.getText().toString().trim());
    ref.addValueEventListener(new ValueEventListener() {
        @Override
        public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
            String fname = dataSnapshot.child("FirstName").getValue().toString();
            String lname = dataSnapshot.child("LastName").getValue().toString();
            String date = dataSnapshot.child("Date").getValue().toString();
            String sal = dataSnapshot.child("Salary").getValue().toString();

            data.setText(fname);
            data1.setText(lname);
            data2.setText(date);
            data3.setText(sal);

        }

        @Override
        public void onCancelled(@NonNull DatabaseError databaseError) {

        }
    });


            }
        });

    }
}