package com.darshan.firebasedb;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class MainActivity extends AppCompatActivity {

EditText fName, lName, jdate, sal,idx;
Button send,read;
DatabaseReference database,x;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        idx = (EditText)findViewById(R.id.id);
        fName = (EditText)findViewById(R.id.fname);
        lName = (EditText)findViewById(R.id.lname);
        jdate = (EditText)findViewById(R.id.date);
        sal = (EditText)findViewById(R.id.salary);
        send = (Button)findViewById(R.id.button);
        read = (Button)findViewById(R.id.button2);
        read.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(v.getContext(), readData.class);
                startActivity(intent);            }
        });
        send.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                database = FirebaseDatabase.getInstance().getReference().child("user");
                x = database.child(idx.getText().toString().trim());
//                database.child("userid").setValue(idx.toString());
                x.child("FirstName").setValue(fName.getText().toString().trim());
                x.child("LastName").setValue(lName.getText().toString().trim());
                x.child("Date").setValue(jdate.getText().toString().trim());
                x.child("Salary").setValue(sal.getText().toString().trim());

            }
        });














//        UserInfo emp = new UserInfo();

//        DatabaseReference branch = database.getReference().child("user");
//
//        emp.setFname("Sahil");
//        emp.setLname("Patel");
//
//        emp.setDate("2020-01-01");
//        emp.setSal(2000.00);

//        database.setValueAsync(emp);


    }

}